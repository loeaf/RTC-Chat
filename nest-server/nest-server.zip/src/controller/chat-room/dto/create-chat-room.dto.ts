export class CreateChatRoomDto {
  _id: string;
  sc_room_id: string;
  admin_id: string;
  user_id: string;
}
