import { Injectable } from '@nestjs/common';
const StreamChat = require('stream-chat').StreamChat;

@Injectable()
export class AppService {
}
