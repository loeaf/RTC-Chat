export class CreateUserInteractiveDto {}
